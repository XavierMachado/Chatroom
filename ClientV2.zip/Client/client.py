"""
Name: Xavier Machado

Date: 03/10/2024

Description: The My Chat Room Client is a Python program that allows users to connect to a chat room server, log in, 
and participate in text-based communication with other users. 
It provides features such as user authentication, new user registration, messaging, active user list display, and logout functionality.
The client serves as the interface through which users interact with the chat room server, enabling them to send and receive messages and
view active users.

"""

import socket
import threading

def receive_message(client_socket):
    """Receives and decodes messages from the server."""
    try:
        while True:
            message = client_socket.recv(1024).decode().strip()
            if not message:
                print("Connection lost.")
                break
            if message.startswith("Active users:"):
                print(message)
            else:
                print(message)
                print("> ", end="", flush=True)  # Print the prompt character ">" without a newline
    except OSError:
        print("Connection lost.")

def send_command(client_socket, command, *args):
    """Sends a formatted command and arguments to the server."""
    formatted_command = f"{command} {' '.join(args)}".encode()
    client_socket.send(formatted_command)

def login(client_socket, username, password):
    """Sends login command to the server and handles response."""
    send_command(client_socket, "login", username, password)
    response = client_socket.recv(1024).decode().strip()
    if response == "Login confirmed.":
        print(f"> Logged in as {username}")
        return username
    else:
        print(f"> {response}")
        return None

def new_user(client_socket, username, password):
    """Sends newuser command to the server and handles response."""
    send_command(client_socket, "newuser", username, password)
    response = client_socket.recv(1024).decode().strip()
    print(f"> {response}")

def send_message_all(client_socket, message):
    """Sends a message to all users."""
    send_command(client_socket, "send", "all", message)

def send_message_user(client_socket, recipient, message):
    """Sends a message to a specific user."""
    send_command(client_socket, "send", recipient, message)

def main():
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect(("127.0.0.1", 18227))
    print("Connected to server.")
    print("My chatroom. Functionality includes:\n'login', 'newuser', 'send all', 'send <username>', 'who', 'logout'")

    logged_in = False
    username = None

    while True:
        if not logged_in:
            # Login or new user flow
            command = input("> ")
            parts = command.split()
            if len(parts) == 3 and parts[0] == "login":
                username = login(client_socket, parts[1], parts[2])
                if username is not None:
                    logged_in = True
                    # Start the receive thread after successful login
                    receive_thread = threading.Thread(target=receive_message, args=(client_socket,))
                    receive_thread.daemon = True
                    receive_thread.start()
                continue
            elif len(parts) == 3 and parts[0] == "newuser":
                new_user(client_socket, parts[1], parts[2])
            elif command.startswith("send"):
                print("Denied. Please Login first.")
            else:
                print("Invalid command.\n Available commands, 'login', 'newuser'")
                continue
        else:
            # Send message, see active users, or logout
            command = input("> ")
            if command == "logout":
                send_command(client_socket, command)
                break
            elif command.startswith("send all"):
                parts = command.split(" ", 1)
                if len(parts) < 2:
                    print("Invalid command format.")
                    continue
                message = parts[1]
                send_message_all(client_socket, message)
                continue
            elif command.startswith("send"):
                parts = command.split(" ", 2)
                if len(parts) < 3:
                    print("Invalid command format.")
                    continue
                recipient = parts[1]
                message = parts[2]
                send_message_user(client_socket, recipient, message)
                continue
            elif command == "who":
                send_command(client_socket, command)
                continue
            else:
                print("Invalid command.\nAvailable commands: 'send', 'who', 'logout'")
                continue

    client_socket.close()

if __name__ == "__main__":
    main()
