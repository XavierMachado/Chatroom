"""
Name: Xavier Machado

Date: 03/10/2024

Description: The My Chat Room Server is a Python program that enables multiple clients to connect and communicate with each other through text messages in a chat room environment. 
It provides features such as user authentication, messaging, active user list display, and logout functionality.
The server facilitates real-time communication between connected clients, allowing users to interact with each other seamlessly, being the
central component in managing client connections and message distribution within the chat room.

"""

import socket
import threading
import os

MAX_CLIENTS = 3
USER_FILE = "users.txt"
active_clients = {}  # Dictionary to map client sockets to usernames 
username_to_socket = {}  # Dictionary to map usernames to client sockets

def load_users():
    """Loads existing user accounts from the file."""
    users = {}
    if os.path.exists(USER_FILE):
        with open(USER_FILE, "r") as file:
            for line in file:
                parts = line.strip().strip("()").split(",")
                if len(parts) >= 2:
                    username = parts[0].strip().lower()
                    password = parts[1].strip()
                    users[username] = password
                else:
                    print(f"Issue loading user: {line.strip()}")
    return users

def save_user(username, password):
    """Appends a new user account to the file."""
    with open(USER_FILE, "a") as file:
        file.write(f"\n({username}, {password})")  

def handle_new_user(client_socket, username, password):
    """Creates a new user account if username is valid and unique."""
    if len(username) < 3 or len(username) > 32 or len(password) < 4 or len(password) > 8:
        client_socket.send(b"Denied. Username or password length invalid.")
        return

    users = load_users()
    username_lower = username.lower()
    if username_lower in users:
        client_socket.send(b"Denied. User account already exists.")
        return

    save_user(username, password)
    client_socket.send(b"New user account created. Please login.")
    print(f"New user account created: {username}")

def notify_active_users(message, sender_username):
    """Sends a notification message to all active users except the sender."""
    for client_socket, username in active_clients.items():
        if username != sender_username:  # Exclude the sender from receiving the notification
            try:
                client_socket.send(message.encode())
            except OSError:
                print(f"Error sending notification to {username}. Removing from active clients.")
                del active_clients[client_socket]

def handle_login(client_socket, username, password):
    """Verifies login credentials and sends confirmation/denial message."""
    users = load_users()
    username_lower = username.lower()
    if username_lower not in users or users[username_lower] != password:
        client_socket.send(b"Denied. User name or password incorrect.")
        return None

    client_socket.send(b"Login confirmed.")
    print(f"{username_lower} login.")
    active_clients[client_socket] = username_lower  # Add the client socket to active clients
    username_to_socket[username_lower] = client_socket  # Update username_to_socket mapping
    notify_active_users(f"{username_lower} has logged in.", username_lower)  # Notify all active users excluding the sender
    return username_lower

def handle_send_all(client_socket, message, sender):
    """Broadcasts the message to all connected clients."""
    if not message:
        client_socket.send(b"Denied. Message cannot be empty.")
        return

    message = message.replace("all ", "", 1)  # Remove "all" from the beginning of the message
    message_with_username = f"{sender}: {message}"
    print(f"{message_with_username}")

    for client, username in list(active_clients.items()):
        if username != sender:  # Exclude the sender from receiving the message
            try:
                client.send(message_with_username.encode())
            except OSError:
                print(f"Error sending message to {username}. Removing from active clients.")
                del active_clients[client]

def handle_send_user(client_socket, recipient, message, sender):
    """Unicasts the message to a specific user."""
    if not message:
        client_socket.send(b"Denied. Message cannot be empty.")
        return

    message_with_username = f"{sender}: {message}"
    print(f"{message_with_username} (to {recipient})")

    # Get the recipient's socket from the username_to_socket mapping
    recipient_socket = username_to_socket.get(recipient)
    if recipient_socket:
        try:
            recipient_socket.send(message_with_username.encode())
        except OSError:
            print(f"Error sending message to {recipient}. Removing from active clients.")
            del username_to_socket[recipient]  # Remove entry from username_to_socket
            del active_clients[recipient_socket]  # Remove entry from active_clients
    else:
        client_socket.send(f"User {recipient} not found or offline.".encode())

def handle_who(client_socket):
    """Sends a list of all users in the chat room."""
    users_list = ", ".join(active_clients.values())
    if users_list:
        client_socket.send(("Active users: " + users_list).encode())  # Prefix with "Active users: "
    else:
        client_socket.send(b"No active users.")

def handle_logout(client_socket, username):
    """Removes the client from the active list and sends a logout acknowledgment."""
    del active_clients[client_socket]  # Remove the client socket from the active_clients dictionary
    notify_active_users(f"{username} has logged out.", username)  # Notify all active users excluding the sender
    #client_socket.send(b"Logout successful.")
    print(f"{username} logout.")
    client_socket.close()

def handle_client(client_socket):
    """Handles communication with a single client."""
    username = None
    while True:
        try:
            data = client_socket.recv(1024).decode().strip()
            if not data:
                break

            parts = data.split(" ")
            command = parts[0]

            if command == "newuser":
                handle_new_user(client_socket, parts[1], parts[2])
            elif command == "login":
                username = handle_login(client_socket, parts[1], parts[2])
                if username is not None:
                    active_clients[client_socket] = username  # Associate username with client socket
                    username_to_socket[username] = client_socket  # Update username_to_socket mapping
            elif command == "send":
                if len(parts) < 3:
                    client_socket.send(b"Denied. Command format incorrect.")
                    continue
                recipient = parts[1]
                message = " ".join(parts[2:])
                if recipient.lower() == "all":
                    handle_send_all(client_socket, message, username)
                else:
                    handle_send_user(client_socket, recipient, message, username)
            elif command == "who":
                handle_who(client_socket)
            elif command == "logout":
                handle_logout(client_socket, username)
                break
            else:
                client_socket.send(b"Invalid command.")
                break
        except ConnectionResetError:
            if username:
                handle_logout(client_socket, username)
        except OSError:
            if username:
                print(f"{username} disconnected unexpectedly.")
                del active_clients[client_socket]
                del username_to_socket[username]  # Remove entry from username_to_socket
            break

def main():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(("127.0.0.1", 18227))
    server_socket.listen(MAX_CLIENTS)
    print("My chat room server. Version Two.")
    print("Server started.")

    while True:
        client_socket, addr = server_socket.accept()
        print(f"Connection from {addr}")
        client_thread = threading.Thread(target=handle_client, args=(client_socket,))
        client_thread.start()

if __name__ == "__main__":
    main()
